import {View, Text} from 'react-native';
import React from 'react';
import AppNavigator from './src/AppNavigator';

const App = () => {
  return <AppNavigator />;
};

export default App;
